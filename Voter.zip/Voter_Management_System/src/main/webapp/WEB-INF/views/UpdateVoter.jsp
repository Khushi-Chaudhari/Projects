<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Voter</title>

<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f9;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .form-container {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        width: 350px;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    label {
        font-weight: bold;
        display: block;
        margin-top: 10px;
    }

    input {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    button {
        width: 100%;
        margin-top: 20px;
        padding: 10px;
        background: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }

    button:hover {
        background: #45a049;
    }
</style>

</head>
<body>

<div class="form-container">

<h2>&#x270F;&#xFE0F; Update Voter</h2>

<form action="/update" method="post">

    <input type="hidden" name="voterId" value="${voter.voterId}">

    <label>Name</label>
    <input type="text" name="name" value="${voter.name}" required>

    <label>Age</label>
    <input type="number" name="age" value="${voter.age}" required>

    <label>Email</label>
    <input type="email" name="email" value="${voter.email}" required>

    <label>Mobile</label>
    <input type="text" name="mobile" value="${voter.mobile}" required>

    <label>Address</label>
    <input type="text" name="address" value="${voter.address}">

    <label>Password</label>
    <input type="text" name="password" value="${voter.password}" required>

    <button type="submit">
        &#x1F4DD; Update
    </button>

</form>

</div>

</body>
</html>