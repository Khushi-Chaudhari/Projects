<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Voter Management System</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(-45deg,#0f172a,#1e3a8a,#2563eb,#38bdf8);
    background-size:400% 400%;
    animation:gradientBG 10s ease infinite;
    overflow:hidden;
}

@keyframes gradientBG{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

.container{
    width:90%;
    max-width:1100px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(15px);
    border-radius:25px;
    padding:50px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 15px 40px rgba(0,0,0,0.3);
    animation:fadeIn 1.5s ease;
}

@keyframes fadeIn{
    from{
        opacity:0;
        transform:translateY(40px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

.left{
    width:55%;
    color:white;
}

.left h1{
    font-size:55px;
    margin-bottom:15px;
}

.left h1 span{
    color:#ffd700;
}

.left p{
    font-size:18px;
    line-height:1.8;
    margin-bottom:30px;
}

.btn-group{
    display:flex;
    gap:20px;
}

.btn{
    text-decoration:none;
    padding:14px 35px;
    border-radius:50px;
    font-weight:600;
    transition:0.4s;
}

.login{
    background:white;
    color:#1e3a8a;
}

.register{
    background:#ffd700;
    color:#000;
}

.btn:hover{
    transform:translateY(-5px);
    box-shadow:0 10px 20px rgba(0,0,0,0.3);
}

.right{
    width:40%;
    text-align:center;
}

.vote-icon{
    font-size:180px;
    animation:float 3s ease-in-out infinite;
}

@keyframes float{
    0%{
        transform:translateY(0px);
    }
    50%{
        transform:translateY(-20px);
    }
    100%{
        transform:translateY(0px);
    }
}

.features{
    margin-top:30px;
}

.features p{
    margin:10px 0;
    font-size:16px;
}

.footer{
    position:absolute;
    bottom:20px;
    color:white;
    font-size:14px;
}

@media(max-width:900px){

.container{
    flex-direction:column;
    text-align:center;
}

.left,
.right{
    width:100%;
}

.left h1{
    font-size:38px;
}

.btn-group{
    justify-content:center;
}

.vote-icon{
    font-size:120px;
    margin-top:30px;
}
}
</style>
</head>

<body>

<div class="container">

    <div class="left">

        <h1>&#128499; <span>Voter Management</span> System</h1>

        <p>
            A secure and transparent platform for voter registration,
            election participation, and election management.
            Empowering democracy through technology.
        </p>

        <div class="btn-group">
            <a href="/login" class="btn login">Login</a>
            <a href="/register" class="btn register">Register</a>
        </div>

        <div class="features">
            <p>&#10004; Secure Authentication</p>
            <p>&#10004; Easy Voter Registration</p>
            <p>&#10004; Real-Time Election Management</p>
            <p>&#10004; Transparent Voting Process</p>
        </div>

    </div>

    <div class="right">
        <div class="vote-icon">&#128499;</div>
    </div>

</div>

<div class="footer">
    &copy; 2026 Voter Management System | All Rights Reserved
</div>

</body>
</html>