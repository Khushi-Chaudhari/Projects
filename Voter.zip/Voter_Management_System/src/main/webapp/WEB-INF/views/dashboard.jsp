<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Voter Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(-45deg,#0f172a,#1e3a8a,#2563eb,#38bdf8);
    background-size:400% 400%;
    animation:gradientBG 10s ease infinite;
}

@keyframes gradientBG{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

.container{
    width:1000px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(15px);
    border-radius:25px;
    padding:40px;
    color:white;
    box-shadow:0 15px 40px rgba(0,0,0,0.3);
}

.header{
    text-align:center;
    margin-bottom:40px;
}

.header h1{
    font-size:42px;
    margin-bottom:10px;
}

.header span{
    color:#ffd700;
}

.header p{
    font-size:18px;
    opacity:0.9;
}

.cards{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:25px;
}

.card{
    background:rgba(255,255,255,0.15);
    border-radius:20px;
    padding:30px;
    text-align:center;
    transition:0.4s;
}

.card:hover{
    transform:translateY(-8px);
    box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

.icon{
    font-size:55px;
    margin-bottom:15px;
}

.card h2{
    margin-bottom:10px;
}

.card p{
    margin-bottom:20px;
    color:#f1f1f1;
}

.btn{
    display:inline-block;
    text-decoration:none;
    padding:12px 25px;
    border-radius:30px;
    background:#ffd700;
    color:black;
    font-weight:600;
    transition:0.3s;
}

.btn:hover{
    transform:scale(1.05);
}

.footer{
    text-align:center;
    margin-top:35px;
}

.logout{
    background:#ff4d4d;
    color:white;
}

.logout:hover{
    background:#ff3333;
}

</style>
</head>

<body>

<div class="container">

    <div class="header">
        <h1>
            &#128499;
            <span>Voter Dashboard</span>
        </h1>

        <p>
            Welcome <b>${voter.name}</b>
        </p>
    </div>

    <div class="cards">

        <div class="card">
            <div class="icon">&#128101;</div>
            <h2>View Voters</h2>
            <p>Display all registered voters.</p>
            <a href="/view" class="btn">
                View All
            </a>
        </div>

       <!--    <div class="card">
            <div class="icon">&#10133;</div>
            <h2>Add Voter</h2>
            <p>Register a new voter into the system.</p>
            <a href="/register" class="btn">
                Register
            </a>
        </div> -->

        <div class="card">
            <div class="icon">&#9998;</div>
            <h2>Update Voter</h2>
            <p>Edit voter information and details.</p>
            <a href="/view" class="btn">
                Update
            </a>
        </div>

        <div class="card">
            <div class="icon">&#128465;</div>
            <h2>Delete Voter</h2>
            <p>Remove voter records from the system.</p>
            <a href="/view" class="btn">
                Delete
            </a>
        </div>

    </div>

    <div class="footer">

        <a href="/" class="btn logout">
            &#128682; Logout
        </a>

    </div>

</div>

</body>
</html>