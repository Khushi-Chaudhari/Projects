<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Voter Registration</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#1e3a8a,#38bdf8);
    padding:20px;
}

.container{
    width:550px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(15px);
    -webkit-backdrop-filter:blur(15px);
    border-radius:20px;
    padding:35px;
    color:white;
    box-shadow:0 10px 30px rgba(0,0,0,0.3);
}

h2{
    text-align:center;
    margin-bottom:25px;
    font-size:28px;
}

.input-group{
    margin-bottom:15px;
}

.input-group label{
    display:block;
    margin-bottom:6px;
    font-weight:500;
}

.input-group input,
.input-group textarea,
.input-group select{
    width:100%;
    padding:12px;
    border:none;
    outline:none;
    border-radius:10px;
    font-size:15px;
    background:rgba(255,255,255,0.9);
}

.input-group textarea{
    resize:none;
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#ffd700;
    color:black;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    margin-top:10px;
}

.btn:hover{
    background:#ffea00;
    transform:scale(1.03);
}

.login-link{
    text-align:center;
    margin-top:15px;
}

.login-link a{
    color:#ffd700;
    text-decoration:none;
    font-weight:600;
}

.login-link a:hover{
    text-decoration:underline;
}

</style>
</head>

<body>

<div class="container">

<h2>&#128100; Voter Registration</h2>

<form action="/Doregister" method="post">

<!--  <div class="input-group">
<label>Voter ID</label>
<input type="text" name="voterId" placeholder="Enter Voter ID" required>
</div>-->

<div class="input-group">
<label>Full Name</label>
<input type="text" name="name" placeholder="Enter Full Name" required>
</div>

<div class="input-group">
<label>Age</label>
<input type="number" name="age" min="18" placeholder="Enter Age" required>
</div>

<div class="input-group">
<label>Gender</label>
<select name="gender" required>
    <option value="">Select Gender</option>
    <option value="Male">Male</option>
    <option value="Female">Female</option>
    <option value="Other">Other</option>
</select>
</div>

<div class="input-group">
<label>Email</label>
<input type="email" name="email" placeholder="Enter Email" required>
</div>

<div class="input-group">
<label>Mobile Number</label>
<input type="tel" name="mobile" maxlength="10" placeholder="Enter Mobile Number" required>
</div>

<div class="input-group">
<label>Address</label>
<textarea rows="3" name="address" placeholder="Enter Address" required></textarea>
</div>

<div class="input-group">
<label>Password</label>
<input type="password" name="password" placeholder="Enter Password" required>
</div>

<button type="/Doregister" class="btn">
&#9989; Register
</button>

</form>

<div class="login-link">
Already have an account?
<a href="login">Login Here</a>
</div>

</div>

</body>
</html>
