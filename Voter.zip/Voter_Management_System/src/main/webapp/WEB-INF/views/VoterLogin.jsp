<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Voter Login</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f172a,#2563eb);
}

.container{
    width:400px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(15px);
    padding:40px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.3);
    color:white;
}

h2{
    text-align:center;
    margin-bottom:25px;
}

.input-group{
    margin-bottom:20px;
}

label{
    display:block;
    margin-bottom:8px;
}

input{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    outline:none;
}

.btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#ffd700;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
}

.btn:hover{
    transform:scale(1.03);
}

.register-link{
    text-align:center;
    margin-top:15px;
}

a{
    color:#ffd700;
    text-decoration:none;
}
</style>
</head>

<body>

<div class="container">

<h2>&#128274; Voter Login</h2>

<form action="login" method="post">

<div class="input-group">
<label>Email</label>
<input type="email" name="email" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="password" name="password" required>
</div>

<button type="submit" class="btn">Login</button>

</form>

<div class="register-link">
Don't have an account?
<a href="register.jsp">Register Here</a>
</div>

</div>

</body>
</html>