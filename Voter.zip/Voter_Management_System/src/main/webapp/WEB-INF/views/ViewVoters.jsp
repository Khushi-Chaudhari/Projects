<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Voters</title>

<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f9;
        margin: 0;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #333;
    }

    table {
        width: 90%;
        margin: auto;
        border-collapse: collapse;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    th {
        background: #4CAF50;
        color: white;
        padding: 12px;
    }

    td {
        padding: 10px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    tr:hover {
        background: #f1f1f1;
    }

    a {
        text-decoration: none;
        margin: 0 5px;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 14px;
    }

    .edit {
        background: #2196F3;
        color: white;
    }

    .delete {
        background: #f44336;
        color: white;
    }
</style>

</head>
<body>

<h2>&#x1F5F3;&#xFE0F; All Voters List</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Actions</th>
    </tr>

    <c:forEach items="${voters}" var="v">
        <tr>
            <td>${v.voterId}</td>
            <td>${v.name}</td>
            <td>${v.age}</td>
            <td>${v.email}</td>
            <td>${v.mobile}</td>
            <td>
                <a class="edit" href="/edit/${v.voterId}">&#x270F;&#xFE0F; Edit</a>
                <a class="delete" href="/delete/${v.voterId}" onclick="return confirm('Are you sure?')">
                    &#x1F5D1;&#xFE0F; Delete
                </a>
            </td>
        </tr>
    </c:forEach>

</table>

</body>
</html>