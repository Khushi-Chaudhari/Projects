<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registration Successful</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f172a,#1e3a8a,#2563eb,#38bdf8);
    background-size:400% 400%;
    animation:gradientBG 10s ease infinite;
}

@keyframes gradientBG{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

.container{
    width:600px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(15px);
    -webkit-backdrop-filter:blur(15px);
    border-radius:25px;
    padding:40px;
    text-align:center;
    color:white;
    box-shadow:0 15px 35px rgba(0,0,0,0.3);
}

.success-icon{
    font-size:90px;
    margin-bottom:15px;
}

h1{
    margin-bottom:15px;
    color:#ffd700;
}

.welcome{
    font-size:22px;
    margin-bottom:15px;
}

.info{
    font-size:17px;
    margin:10px 0;
}

.voter-id{
    background:rgba(255,255,255,0.15);
    padding:12px;
    border-radius:10px;
    margin:20px 0;
    font-size:18px;
}

.btn{
    display:inline-block;
    margin-top:20px;
    padding:12px 30px;
    background:#ffd700;
    color:black;
    text-decoration:none;
    border-radius:30px;
    font-weight:600;
    transition:0.3s;
}

.btn:hover{
    transform:translateY(-3px);
    box-shadow:0 10px 20px rgba(0,0,0,0.3);
}

.footer{
    margin-top:25px;
    font-size:14px;
    opacity:0.8;
}

</style>
</head>

<body>

<div class="container">

    <div class="success-icon">✅</div>

    <h1>Registration Successful</h1>

    <div class="welcome">
        Welcome, <b>${voter.name}</b>!
    </div>

    <p class="info">
        Your voter account has been created successfully.
    </p>

    <div class="voter-id">
        <strong>Voter ID :</strong> ${voter.voterId}
    </div>

    <p class="info">
        You can now login and participate in the voting process.
    </p>

    <a href="/login" class="btn">
        Login Now
    </a>

    <div class="footer">
        Voter Management System © 2026
    </div>

</div>

</body>
</html>