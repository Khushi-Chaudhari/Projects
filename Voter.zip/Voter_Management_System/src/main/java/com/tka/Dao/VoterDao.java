package com.tka.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tka.Model.Voter;

public interface VoterDao extends JpaRepository<Voter, Integer>{

}