package com.tka.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.Dao.VoterDao;
import com.tka.Model.Voter;

@Service
public class VoterService {

    @Autowired
    VoterDao voterDao;

    public boolean doRegistration(Voter voter) {

        Voter v=voterDao.save(voter);

        return v!=null;
    }

    public Voter login(String email,String password) {
    		List<Voter> voter=voterDao.findAll();
    		for (Voter voter2 : voter) {
				if(voter2.getEmail().equals(email) && voter2.getPassword().equals(password)) {
					return voter2;
				}
			}
    		return null;
    }

    public List<Voter> getAllVoters(){

        return voterDao.findAll();
    }

    public void deleteVoter(int voterId) {

        voterDao.deleteById(voterId);
    }

    public Voter getVoterById(int voterId) {

        return voterDao.findById(voterId).orElse(null);
    }

    public void updateVoter(Voter voter) {

        voterDao.save(voter);
    }
}