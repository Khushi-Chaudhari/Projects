package com.tka.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.tka.Model.Voter;
import com.tka.Service.VoterService;

@Controller
public class VoterController {
	
	@Autowired VoterService voterService;
	
	@GetMapping("/")
	public String openIndexPage() {
		System.err.println("Index Page is successFully Shown....");
		return "index";
	}
	
	@PostMapping("/login")
	public String login(@PathVariable String email,@PathVariable String password,Model model) {
		Voter voter=voterService.login(email,password);
		if(voter!=null) {
			model.addAttribute("voter",voter);
	        return "dashboard";
	    }
		return "VoterLogin";
	}
	
	@GetMapping("/register")
	public String showRegiatrationPage() {
		System.err.println("Registration Page shown....");
		return "VoterRegistration";
	}
	
	@PostMapping("/Doregister")
	public String doRegistration(Voter voter) {
		boolean voter2=voterService.doRegistration(voter);
		if(voter2) {
			return "Success";
		}
		return "VoterRegistration";
	}
	
	@GetMapping("/view")
	public String viewVoters(Model model) {
		List<Voter> list=voterService.getAllVoters();
		model.addAttribute("voters",list);
		return "ViewVoters";
	}
	
	@GetMapping("/delete/{id}")
	public String deleteVoter(@PathVariable("id") int id) {
		voterService.deleteVoter(id);
		return "redirect:/view";
	}
	
	@GetMapping("/edit/{id}")
	public String editVoter(@PathVariable("id") int id,Model model) {
		Voter voter=voterService.getVoterById(id);
		model.addAttribute("voter",voter);
		return "UpdateVoter";
	}
	
	
	@PostMapping("/update")
	public String updateVoter(Voter voter) {
		voterService.updateVoter(voter);
		return "redirect:/view";
	}
	
}
