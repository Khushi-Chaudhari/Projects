package com.tka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoterManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoterManagementSystemApplication.class, args);
		System.err.println("Application Started....");
	}

}
